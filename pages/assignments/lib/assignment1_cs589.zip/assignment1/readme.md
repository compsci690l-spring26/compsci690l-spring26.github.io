Details about this assignment can be found [on the course webpage](https://compsci589-summer24.github.io/pages/assignments/), under Assignment #1 of Summer 2024.
