from cs589.classifiers.k_nearest_neighbor import *
from cs589.classifiers.linear_classifier import *
